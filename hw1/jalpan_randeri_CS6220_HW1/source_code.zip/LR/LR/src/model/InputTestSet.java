package model;

/**
 * Created by jalpanranderi on 1/30/15.
 */
public class InputTestSet {
    public Question input;
    public Question test;
}
