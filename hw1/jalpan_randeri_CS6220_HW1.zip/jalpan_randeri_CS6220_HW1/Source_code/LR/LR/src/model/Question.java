package model;

import Jama.Matrix;

/**
 * Model for holding the data
 *
 * Created by jalpanranderi on 1/25/15.
 */
public class Question {
    public Matrix mat_x;
    public Matrix mat_y;
}
